import React from "react";

function List(){
    return (
    <ol>
    <li>first</li>
    <li>Second</li>
    <li>Third</li>
  </ol> );

}

export default List;