import React from "react";

function Para(){
    return <p>This is my world</p>

}

export default Para;